  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA9iMQEirR-iR_LSrtGImwiJoFGP9jVpAk",
    authDomain: "blowing-d733c.firebaseapp.com",
    databaseURL: "https://blowing-d733c.firebaseio.com",
    storageBucket: "blowing-d733c.appspot.com",
    messagingSenderId: "891636356835"
  };
  firebase.initializeApp(config);